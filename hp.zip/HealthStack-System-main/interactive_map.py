#!pip install folium
import folium
import io
from PIL import Image
import os


map_1 = folium.Map(location=[43.2352, 76.90988], zoom_start=15)
folium.CircleMarker(location=[43.2352, 76.90988], radius=15, popup="Christ the Redeemer").add_to(map_1)
folium.Marker(location=[43.2352, 76.90988], popup="Christ the Redeemer").add_to(map_1)
map_1.save("map1.html")


project_folder = os.getcwd()

# Define the path to the templates folder
templates_folder = os.path.join(project_folder, 'templates')

# Check if the templates folder exists, if not, create it
if not os.path.exists(templates_folder):
    os.makedirs(templates_folder)

img_data = map_1._to_png(5)
img = Image.open(io.BytesIO(img_data))
# Save the image in the templates folder
img.save(os.path.join(templates_folder, 'image1.png'))



#img_data = map_1._to_png(5)
#img = Image.open(io.BytesIO(img_data))
#img.save('temple/image.png')

